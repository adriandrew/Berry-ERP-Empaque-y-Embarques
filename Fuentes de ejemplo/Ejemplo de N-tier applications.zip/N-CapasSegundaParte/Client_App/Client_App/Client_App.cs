using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Client_App
{
    public partial class Client_App : Form
    {
        public Client_App()
        {
            InitializeComponent();
        }
        DataSet dsdata = new DataSet();

        private void btnsearch_Click(object sender, EventArgs e)
        {
         
            BLL.BLL obj = new BLL.BLL();
            String strsearch = txtsearch.Text.Trim();
            try
            {
                dsdata = obj.Search_Client(strsearch);

                if (dsdata.Tables[0].Rows.Count < 1)
                {
                    MessageBox.Show("Record not Found");
                }
                else
                {
                    dataGridView1.DataSource = dsdata;
                    dataGridView1.DataMember = "Products";
                }
                       
            }
            catch (ApplicationException ex)
            {   
                MessageBox.Show(ex.Message);
            }
                  
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            BLL.BLL obj = new BLL.BLL();
            
            try
            {
                if (dsdata.HasChanges()) 
                {
                    obj.Update_Records(dsdata);
                    MessageBox.Show("Updated"); 
                    
                }
                else
                {
                    MessageBox.Show("No Changes Made");
                   
                }
            }
            catch (ApplicationException ex)
            {
                MessageBox.Show(ex.Message);
            }
      }

        private void btndelete_Click(object sender, EventArgs e)
        {
          
         }

        private void Client_App_Load(object sender, EventArgs e)
        {

        }
    }
}