using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class DAL
    {
        //Please Change the Connection String to your liking. i have used the @@ and myserver

        String strcon = @"User id =sde;Password=@@@@@;Server=myserver;Database=ValRollClients";
        SqlCommand cmdselect = null;
        SqlCommand cmdupdate = null;
        SqlCommand cmddelete = null;
        SqlConnection con;
        SqlDataAdapter da;

       /*=====================================================================
        //This Function is Being Called from the BLL, and it uses SP's, and   
        //Delete the Data
        ======================================================================*/

        public void Delete_Client(DataSet dsdata)
        {

            con = new SqlConnection(strcon);
            cmddelete = new SqlCommand();
            cmddelete.CommandText = "Delete_Record";
            cmddelete.CommandTimeout = 0;
            cmddelete.CommandType = CommandType.StoredProcedure;
            cmddelete.Connection = con;

            cmddelete.Parameters.Add("@Pro_id",SqlDbType.Int,4,"Pro_id");

            cmddelete.Parameters["@Pro_id"].Value = "Prop_Id";


            try
            {
                con.Open();

                cmddelete.ExecuteNonQuery();

                con.Close();
            }
            catch (SqlException)
            {
                throw;
            }
        }

        public DataSet Search_Client(String strClient)
        {
            DataSet ds = new DataSet();
            con = new SqlConnection(strcon);
            cmdselect  = new SqlCommand();
            cmdselect.CommandText = "SEARCH_CLIENT";
            cmdselect.CommandTimeout = 0;
            cmdselect.CommandType = CommandType.StoredProcedure;
            cmdselect.Connection = con;
            da = new SqlDataAdapter(cmdselect);
            cmdselect.Parameters.Add(new SqlParameter("@CLIENT_NAME",SqlDbType.VarChar, 12,"Client_name"));
            cmdselect.Parameters["@CLIENT_NAME"].Value = strClient;


            try
            {
                con.Open();

                da.Fill(ds,"Products");    

                con.Close();
            }
            catch (SqlException)
            {   
                throw;
            }
             return ds;
        }

        public void  Update_Records(DataSet dsdata)
        {
            da = new SqlDataAdapter();
            con = new SqlConnection(strcon);
            //For Update
            cmdupdate = new SqlCommand();
            cmdupdate.CommandType = CommandType.StoredProcedure;
            cmdupdate.CommandText = "Update_Status_Grid";
            cmdupdate.CommandTimeout = 0;
            cmdupdate.Connection = con;
            //For Delete
            cmddelete = new SqlCommand();
            cmddelete.CommandText = "Delete_Record";
            cmddelete.CommandTimeout = 0;
            cmddelete.CommandType = CommandType.StoredProcedure;
            cmddelete.Connection = con;


            //Adding Parameters  for Update 

            cmdupdate.Parameters.Add("@Original_Pro_id", SqlDbType.Int, 4, "Pro_id");

            cmdupdate.Parameters["@Original_Pro_id"].SourceVersion = DataRowVersion.Original;

            cmdupdate.Parameters.Add("@Original_Delivered",SqlDbType.Int,4,"Delivered");

            cmdupdate.Parameters["@Original_Delivered"].SourceVersion = DataRowVersion.Original;
            cmdupdate.Parameters.Add("@Delivered", SqlDbType.Int, 4, "Delivered");

         //   Adding Parameters for Delete
            cmddelete.Parameters.Add("@Pro_id", SqlDbType.Int, 4, "Pro_id");

            cmddelete.Parameters["@Pro_id"].Value = "Prop_Id";

       //Telling the Adapter that we are going to use this Command Object for that

            da.UpdateCommand = cmdupdate;
            da.DeleteCommand = cmddelete;



            try
            {

                con.Open();

                da.Update(dsdata, "Products");

                con.Close();

            }
            catch (SqlException)
            {
                throw;
            }
    
        }

        
    }
}
