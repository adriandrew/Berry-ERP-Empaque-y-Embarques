using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
namespace clsDAL
{
    public class DAL
    {   /*Declaring a String Variable and assign a Connection String to it*/
        String strcon  = @"User ID  = sde ; Password = topology; Server =SGIICORNETGS01;Database =ValRollClients";
        
         SqlCommand cmdinserted;//In this line we are declaring a command object for inserting
         SqlConnection con; //declaring a Connection object 
        
        /*The Following method is Going to Insert Client Details into the Client_Details table. 
        Our Presentation Layer will need us to save the Data into our Database, the main objective of this 
        Project is to Show how we do N-Tier Application and from this Example we are only going to Add 
        data into the database.Now the Following Method is going to save data that is valid into the Database, the Data is Accepted 
        from the BLL, that means the Data has passed the Business Rules that we have set and some 
        Calculations has been done if needed. This Method Accepts 3 parameters , that means BLL has to Supply 
        3 valid paramters to the DAL to insert the Data into the database. And we are going to use a Stored procedure to
        avoid sql injection and besides that using Stored Procedure is Easier than using naked SQl statements, if you want
        info on SQL injection follow the link http://msdn2.microsoft.com/en-us/library/ms161953.aspx
        now the SQL Procedure is already defined as we have seen.*/


        public void insert_Clients(String Client_name, String Client_Lastname, int Client_Age)
        {
            cmdinserted = new SqlCommand(); /* instatiating the inserted command object that we have declared earlier
            if you look at this code, it can be written in one line, but for the Purpose of understanding we have to
            break it into parts */
            cmdinserted.CommandText = "[dbo].[prcInsert_Client]"; /*Now here we are passing the StoredProcedure name in the Command text
            the Command Text carries the SQl statement, if we decided to use naked SQl Statement, we would have have something like
            "select * from Table", but we used a StoredProcedure instead. */

            cmdinserted.CommandTimeout = 0; /*in this line we want to avoid the time out Exceptions by setting the number to infinite, but 
             microsoft rememended us to use a number. */

            cmdinserted.CommandType = CommandType.StoredProcedure; //We are telling the Command object that we are going to use a Stored Procedure

            con = new SqlConnection(strcon); //We are initializing the Connection object and Pass the Connection string in the Constructor

            cmdinserted.Connection = con; //We are telling the Connection object what connection we are going to use
            //Below we are Adding Paramers to the Command object to insert, as we have seen that our Stored Procedure will 
            //reqiured some Paramters. ok lets Explain this Statement in Detail 

            cmdinserted.Parameters.Add("@Client_name", SqlDbType.VarChar, 12).Value = Client_name;

            cmdinserted.Parameters.Add("@Client_Lastname", SqlDbType.VarChar, 15).Value = Client_Lastname;

            cmdinserted.Parameters.Add("@Client_Age ", SqlDbType.Int, 4).Value = Client_Age;
            /*from the command object inserted we add a Parameter and name it Client_Age, remember 
           that the paramter should be in quotes and the datatype and the demension must be the 
           same as the one defined in the table,or else you will encounter the problems and another thing, the order 
           * of variable decleration in your Procedure should be the same as the order in your vb or C# code.
           * Now the last part of the code,we are assigning the value to the parameter from the string that 
           * has been acceped from BLL in our method. i hope the Explanation is Clear*/
            try
            {
                con.Open(); //open Connection

                cmdinserted.ExecuteNonQuery(); //execute the Storepd Procedure

                con.Close();//Close Connection

            }
            catch (SqlException) //catch an Error
            {
                throw; //Throw it back to the Calling Method 
            }
        }
    
     

    }
}
