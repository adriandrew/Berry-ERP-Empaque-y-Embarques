using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace clsBLL
{
    public class BLL
    {
        public void Save_Client(string Clientname,string Clientlastname,string Clientage)
        {
            Boolean bopassed = true  ; //Declare a Boolean variable
           /*assgning the Boolean results from the Check_Rules function to 
            * the variable bopassed, that means the data is valid*/
            bopassed  = Check_Rules(Clientname, Clientlastname,Clientage);
            clsDAL.DAL obj = new clsDAL.DAL();//Creating an object of a Class and instatiating it

            if (bopassed == true) //if the rules are passed then 
            {
                //save the records 
                obj.insert_Clients(Clientname,Clientlastname,Convert.ToInt32(Clientage));
                MessageBox.Show("Client Added");
            }
            else //else 
            {
                //the Rules are not Passed send the user a notification that somthing is Wrong
                MessageBox.Show("Invalid Data Entry");
                
            }
                

        }

        /*Lets Check the Rules , this is just an Example of what kind of things should be 
         * present in the BLL, it can be Calculations and the Data after the Calculations \
         * should be brought back to correct datatypes that the DAl can understand and they 
         * should be valid..*/
 
        private Boolean  Check_Rules(string Client_name,string Clientlastname,string Clientage)
        { /*we are Accepting the input that was accepted from Client and they are validated for 
           * Empty string later the age will be converted to an integer*/

            Boolean bolres = true; //declaring a boolean variable

            if (Client_name == "")  //testing for Empty string
            {
                bolres = false;  //if its Empty set the bolres variable to false 
            }
                if (Clientlastname == "")
                {
                    bolres = false;
                }

                    if (Clientage =="")
                    {
                        bolres = false;
                    }
                
                         return bolres; /*return a boolean value based on the test, if one of the field say "False" then 
                        then the Function will return false, because remeber the SQl Stored Procedure 
                           * will require all the fields to present.*/
                      }
    }
}
