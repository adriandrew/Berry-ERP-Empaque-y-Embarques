﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using DataAccess;


namespace LoginWebUI
{
    public partial class frmLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ProcessLogin(object sender, EventArgs e)
        {
            if (LoginService.Autenticar(txtUser.Text, txtPassword.Text))
            {
                FormsAuthentication.RedirectFromLoginPage(txtUser.Text, chkPersistLogin.Checked);
            }
            else
                ErrorMessage.InnerHtml = "<b>Usuario o contraseña incorrectos...</b> por favor re-ingrese las credenciales...";
        }
    }
}
