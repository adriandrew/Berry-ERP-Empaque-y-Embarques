﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using DataAccess;

namespace LoginWebUI
{
    public partial class Usuarios : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAceptar_Click(object sender, EventArgs e)
        {
            UsuarioEntity usuario = new UsuarioEntity();

            usuario.Nombre = txtNombre.Text;
            usuario.Apellido = txtApellido.Text;
            usuario.NombreLogin = txtLogin.Text;
            usuario.Password = txtPassword.Text;

            usuario = LoginService.Insert(usuario);

            ClearControls();
            lblMessage.InnerHtml = string.Format("Se ha creado el usuario, ID: {0}", usuario.Id);

        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Default.aspx");
        }

        private void ClearControls()
        {
            txtNombre.Text="";
            txtApellido.Text="";
            txtLogin.Text="";
            txtPassword.Text="";
        }
    }
}
