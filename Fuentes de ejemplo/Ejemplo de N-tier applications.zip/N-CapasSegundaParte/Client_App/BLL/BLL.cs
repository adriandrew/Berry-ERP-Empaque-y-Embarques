using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BLL
{
    public class BLL
    {
        

        public DataSet Search_Client(String strClient)
        {
            DAL.DAL obj = new DAL.DAL();

            DataSet dsdata = new DataSet();
            try
            {
                  dsdata = obj.Search_Client(strClient);

            }
            catch (SqlException e)
            {
                MessageBox.Show(e.Message,"Trapped in BLL");
            
            }
            return dsdata;
        }

        public void Update_Records(DataSet dsdata)
        {
        

            DAL.DAL obj = new DAL.DAL();

            try
            {
               obj.Update_Records(dsdata);

            }
            catch (SqlException e)
            {
                MessageBox.Show(e.Message, "Trapped in BLL");
              
            }
    

        }
    }
}
