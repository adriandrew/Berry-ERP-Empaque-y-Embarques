﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DataAccess;

namespace LoginUI
{
    public partial class frmUsuarios : Form
    {
        public frmUsuarios()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            UsuarioEntity usuario = new UsuarioEntity();

            usuario.Nombre = txtUsuario.Text;
            usuario.Apellido = txtApellido.Text;
            usuario.NombreLogin= txtNombreLogin.Text;
            usuario.Password = txtPassword.Text;

            usuario = LoginService.Insert(usuario);

            MessageBox.Show(string.Format("Se ha creado el usuario, ID: {0}", usuario.Id));
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
